/**
 * 
 */
/**
 * 
 */
module EntrepriseVehiculeHybride {
}