package entreprisevehiculehybride;

public class AutomobileHybride extends Automobile{
	public AutomobileHybride(String Modele, String Couleur, int Puissance, double Masse) {
		super(Modele,Couleur,Puissance, Masse);
	}
	public void AfficheVehicule() {
		System.out.print("Automobile hybride ");
		System.out.print(this.Modele + " ");
		System.out.print(this.Couleur +" ");
		System.out.print(this.Puissance +" ");
		System.out.println(this.Masse + "\n");

	}
}
