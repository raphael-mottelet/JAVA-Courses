package entreprisevehiculehybride;

public class VehiculeElectrique implements Vehicule {
	
	public Automobile CreerAutomobile (String Modele, String Couleur, int Puissance, double Masse) {
		Automobile x = new AutomobileElectrique(Modele,Couleur,Puissance, Masse);
		return x;
	}
	public Scooter CreerScooter(String Modele, String Couleur, int Puissance) {
		Scooter x = new ScooterElectrique(Modele,Couleur,Puissance);
		return x;
	}
}
