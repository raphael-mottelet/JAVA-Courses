package entreprisevehiculehybride;


public class VehiculeHybride implements Vehicule {
	public Automobile CreerAutomobile (String Modele, String Couleur, int Puissance, double Masse) {
		Automobile x = new AutomobileHybride(Modele,Couleur,Puissance, Masse);
		return x;
	}
	public Scooter CreerScooter(String Modele, String Couleur, int Puissance) {
		Scooter x = new ScooterHybride(Modele,Couleur,Puissance);
		return x;
	}
}
